<?php
//数据库连接信息
$cfg_dbhost = 'qdm155063138.my3w.com';
$cfg_dbname = 'qdm155063138_db';
$cfg_dbuser = 'qdm155063138';
$cfg_dbpwd = 'HpoKJgUtTs';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>