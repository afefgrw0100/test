﻿function layoutTiles() {
   var h = $(window).height();
   if(h < 1080){
	  $('body').addClass('x_850');
	   //var h0 = $(document).height();
	  //$("body").height(h0);
	  var h1 = $(".header").outerHeight();
	  var h2 = $(".banner").outerHeight();
	  var h3 = $(".sy_con").outerHeight();
	  var h4 = $(".footer").outerHeight();
	  //$(".gfd").height(h1+h2+h3+h4);
	  $(".flexslider,.flexslider .slides .img").height(h-h1-h3-h4);
     };
   if(h > 850){
	  $('body').addClass('d_850');
     };

}
$(window).ready(function()
{
  	layoutTiles();
});
$(window).resize(function()
{
  	layoutTiles();
});